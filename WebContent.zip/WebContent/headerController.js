
mainApp.controller('headerController', function($scope,$location,$localStorage) {
    this.username = $localStorage.username;
});