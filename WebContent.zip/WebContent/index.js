var mainApp = angular.module("mainApp", ['ngRoute','ngStorage','ui.bootstrap']);
mainApp.config(['$routeProvider', function($routeProvider) {
    $routeProvider.
        when('/', {
        templateUrl: 'login/Login2.html',
        controller: 'LoginController'
    }).
    when('/home', {
        templateUrl: 'home/home.html',
        controller: 'HomeController',
        controllerAs: 'home'
    }).

    when('/menuOne', {
        templateUrl: 'menus/menuOne.html',
        controller: 'MenuOneController'
    }).

    when('/menuTwo', {
        templateUrl: 'menus/menuTwo.html',
        controller: 'MenuTwoController'
    }).
    
    when('/option1', {
        templateUrl: 'menus/option1.html'
    }).

    otherwise({
        redirectTo: '/'
    });
}]);

mainApp.controller('MenuOneController', function($scope) {
    $scope.message = "This page will be used to display add student form";
});

mainApp.controller('MenuTwoController', function($scope) {
    $scope.message = "This page will be used to display all the students";
});
(function($){
    $(document).ready(function(){
        
        $('ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) {
            event.preventDefault();
            event.stopPropagation();
            $(this).parent().siblings().removeClass('open');
            $(this).parent().toggleClass('open');
        });
    });
})(jQuery);