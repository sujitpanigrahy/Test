/**
 * Created by Sujit on 7/1/2016.
 */
mainApp.controller('LoginController', function($scope,$localStorage, $sessionStorage,$location) {
    this.username;
    this.password;
    this.login = function () {
        //TODO do some authentication or call authentication service for login
        this.message='';
        //alert(this.username+'  '+this.password);
        $localStorage.username = this.username;
        
        if(this.username === 'test' &&  this.password === 'test'){        	
        	$location.path('/home');
        	$scope.message = "Login Page";
        }
        else{
        	$scope.message = "Invalid user/password Page";
        	
        }
        
    }
    
    
});